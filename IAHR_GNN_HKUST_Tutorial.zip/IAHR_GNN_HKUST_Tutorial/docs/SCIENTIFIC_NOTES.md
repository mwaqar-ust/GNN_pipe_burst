# Scientific and numerical notes

The tutorial teaches graph neural networks through passive transient source localisation on one known, instrumented pipe network. Its compact encoder and pipe decoder are an educational design. Application context, graph-learning foundations and hydraulic software references are listed in `../REFERENCES.md`.

## What is known and what is estimated

| Known to the model | Estimated by the model | Available only for checking a simulated case |
|---|---|---|
| Original network connectivity, pipe lengths and diameters | Original source pipe | True simulated source pipe |
| Sensor identities and their fixed order | Fraction along that pipe | True source fraction |
| Source-independent graph travel-time landmarks |  | Simulated event onset |
| Relative arrival observations |  | Full hydraulic state and source-specific discretisation |

A source fraction is measured from an original pipe's EPANET start node towards its end node. It is not a node index. The temporary junction used to create a hydraulic burst is absent from the GNN input graph.

Monitoring is passive because no diagnostic excitation is imposed to obtain the observation. The numerical simulator deliberately creates a burst so that the tutorial has an event of known origin for demonstration and evaluation.

## One network, several representations

The supplied case is the retained HKUST primary network: 30 junctions and the fixed-head supply boundary T1, giving 31 nodes connected by 33 original pipes. It is a selected network representation, not a claim to include every campus service connection. The default layout observes J10, J84, J102, J107, J88, J62, J79, J46, J16 and J51 in that order. A 100 m minimum original pipe length leaves 21 eligible source pipes. All 33 pipes remain available to the hydraulic model; a source-location threshold does not delete short pipes from the network.

Different matrices serve different purposes:

1. **Binary adjacency** describes open connections in the selected initial state. It is symmetric in this introductory representation.
2. **Travel-time costs** describe an approximate earliest propagation delay. A pipe contributes its length divided by wave speed.
3. **Normalised adjacency** combines neighbour representations in the GNN.
4. **Geometric distance** uses physical pipe lengths to report location error.

The source CSV contains geographic node coordinates, measured pipe lengths and nominal diameters. Longitude and latitude are projected to a local metre coordinate system for the map. Physical lengths come from the INP and should not be measured from straight lines on the drawing. Coordinates are also included as explicit structural features in this teaching model; their inclusion does not make the map a hydraulic solver.

## Graph travel-time prior

For a source on pipe \(e=(u,v)\) at fraction \(\xi\), let \(D(u,s)\) be the shortest propagation time from endpoint \(u\) to sensor \(s\). The earliest-arrival prior is

\[
T_s(e,\xi)=\min\left[\xi L_e/a_e+D(u,s),\;(1-\xi)L_e/a_e+D(v,s)\right].
\]

The two branches represent waves leaving through opposite ends of the source pipe. This expression predicts first-arrival timing. It does not reconstruct waveform amplitude, attenuation or the later reflected waves.

The default prior uses the initial open-link status and source-independent effective wave speeds from a TSNet discretisation of the original unsplit network. Nominal pipe speeds follow the retained ductile-iron K9 diameter and wall-thickness model, with water bulk modulus 2.1 GPa, density 1,000 kg/m³, pipe Young modulus 165 GPa and Poisson ratio 0.3. They range from approximately 1,137.405 to 1,231.378 m/s for this network. The requested reference time step is 1.04045 ms. TSNet adjusts the numerical time step and individual speeds. These adjusted values are fixed before selecting any source. An explicit scalar `wave_speed` override is available for a separate teaching experiment and requires corresponding data and model preparation.

T1 is represented as a reservoir with a fixed head of 40 m in the controlled hydraulic model. Paths cannot transmit through that boundary node in the travel-time prior. Every retained connection is a pipe; this case has no pumps or valves. Mean-flow advection is neglected in the first-arrival model.

A burst simulation splits its source pipe, which can produce a different numerical time step and slightly different effective speeds. Those event-specific quantities do not update the prior, features or trained GNN. Accordingly, the graph overlay and signal-derived picks need not coincide exactly.

## Unknown event onset

An observed timestamp can be written as

\[
t_s=t_0+T_s(e,\xi)+\epsilon_s.
\]

The tutorial forms relative arrivals

\[
\Delta t_s=t_s-\min_r t_r.
\]

A common shift in every timestamp therefore leaves the input unchanged. The model subsequently mean-centres and scales the timing vector during feature construction.

For the explanatory signal overlay, the simulator's known \(t_0\) places the theoretical line at \(t_0+T_s\). That use is restricted to visual explanation and error inspection. The localisation model receives neither the true onset nor the true source location.

## Hydraulic signals and arrival picking

TSNet solves the transient equations using the method of characteristics. The controlled HKUST simulation uses zero junction elevations and zero initial background demands, a 40 m supply head, and a fixed Darcy friction factor of 0.02. These are declared teaching conditions, not measurements of the current campus operating state. The burst begins at 0.5 s, opens over 0.02 s and uses an emitter coefficient of 0.001/√40 m³/s/√m, corresponding to 0.001 m³/s at 40 m head. The prepared record lasts 3 s.

For each prepared burst, a second run on the same split network, without the burst, supplies a reference for removing small numerical initialisation drift. The total-head histories remain available; subtracting elevation gives pressure head. The burst-response signal is the difference between the burst and no-burst runs. All 30 original junction histories are recorded, so a new sensor selection can use existing traces. The temporary source node is never included.

This reference subtraction is a convenience of the controlled simulation. A field deployment would need an appropriate detector and treatment of its own background variability.

The interactive demonstrations and the main tutorial evaluation rerun the signal picker on the stored 100 Hz traces. A sample interval is therefore 10 ms. Original cached picks made on an event's finer MOC grid remain provenance information and are not substituted for these displayed-signal picks.

The picker uses a fixed record lead-in and a sustained threshold crossing, with a 1 mm absolute head floor, six robust baseline-noise standard deviations and two consecutive crossing samples. Its fixed 0–0.30 s lead-in and 0.30 s search start are the same for every source. It does not use the true source, a graph-predicted arrival window or a preferred location. An undetected arrival is represented explicitly. The present GNN expects a complete, finite sensor timing vector; the interface therefore reports unavailable predictions when required observations are missing.

## Two different sources of uncertainty

**Pressure noise** is added to the recorded burst-response signal in metres of head. The arrival picker is then rerun. The resulting timing errors arise from the interaction between the waveform, noise and detection rule.

**Additional timing uncertainty** perturbs the extracted timestamps in seconds. It represents picking or timestamp uncertainty not already represented by the waveform experiment. Its control can be set to zero.

These quantities should not share a numerical scale or label. A 10 ms timing standard deviation is not a 10 ms bound, and it is not a pressure-noise amplitude. At 100 Hz, a signed error of two to ten samples would mean a magnitude of 20–100 ms, a substantially different error model from a Gaussian standard deviation of 10 ms.

The default graph-prior training uses independent Gaussian absolute-timestamp perturbations with standard deviation 10 ms, followed by rounding to a 10 ms sampling grid. Relative times are calculated afterwards. Although the errors before differencing are independent across sensors, the relative timing errors share a reference and are generally correlated.

The hydraulic evaluation includes a clean recorded-signal condition and a separate condition with 0.005 m background-noise standard deviation and 10 ms additional timestamp-jitter standard deviation. Both use the same retained source events. The notebook reports the applied settings, event counts and detection availability with the location metrics. These teaching settings define specific experiments; they do not claim to represent every field sensor or operating condition.

## Features, embeddings and message passing

The observations are arrival-time features. The GNN does not ingest a pressure waveform directly.

For each node, the features combine:

- Its known, centred travel-time vector to the sensors.
- The observed, centred sensor timing vector, supplied to every node.
- Their difference and its square.
- Normalised drawing coordinates, degree, a boundary flag and a sensor flag.
- The local sensor reading where a sensor exists, and zero otherwise.

For ten sensors there are \(4S+6=46\) input channels. Graph travel-time landmarks and observation differences are explicit physical feature choices. Broadcasting the sensor vector makes that observation available to every node even though the model has only two neighbourhood updates. It is not evidence that two local updates can carry a reading across arbitrarily many edges.

The encoder maps the features into 32-dimensional node embeddings. With

\[
\widehat A=\widetilde D^{-1/2}(A+I)\widetilde D^{-1/2},
\]

one residual message-passing layer applies

\[
H^{(k+1)}=\operatorname{GELU}\!\left(H^{(k)}W_{\mathrm{self}}^{(k)}
+\widehat A H^{(k)}W_{\mathrm{neighbour}}^{(k)}+b^{(k)}\right)+0.2H^{(k)}.
\]

The parameters are shared across nodes. Self-connections allow a node's current representation to contribute to aggregation. Two such layers refine the embeddings before the pipe decoder.

A hidden channel need not correspond to one interpretable physical variable. Heatmaps show learned numerical representations; PCA provides a two-dimensional view of those representations, not a physical map or an independent accuracy measure.

## Pipe and position outputs

A shared decoder combines endpoint embeddings, their absolute difference, timing evidence and pipe attributes. Its two outputs are a pipe score and a position fraction. Ineligible source pipes retain their original indexing but receive zero probability after masking.

A sigmoid bounds each position fraction between zero and one. Training uses classification cross-entropy and the squared position error for the true pipe:

\[
\mathcal L=\operatorname{CE}(p,e_{\mathrm{true}})
+4\left(\widehat\xi_{e_{\mathrm{true}}}-\xi_{\mathrm{true}}\right)^2.
\]

At inference, the predicted pipe is the highest-probability eligible pipe, and its own position fraction supplies the source coordinate. The true pipe is not an input. Softmax values describe model outputs and are not calibrated physical confidence intervals.

## Training and held-out sources

The default source split has 48 training, 12 validation and two held-out graph-prior positions per eligible pipe. At 21 pipes, this gives 1,008, 252 and 42 distinct source positions. The split seed is fixed. Exact pipe endpoints are excluded because a junction source does not have a unique incident-pipe label.

Training repeatedly perturbs the timing vector at a training source while retaining its label. Validation uses a fixed noise realisation. The checkpoint is selected by validation loss, with early stopping. The held-out source labels and hydraulic test scores do not select the saved epoch.

The prepared hydraulic cache contains 21 newly simulated source events, one per eligible original pipe. The first of each pipe's two held-out positions is selected in advance, independently of its eventual prediction. All 21 cases contribute to the report. Those source locations are held out from training and validation. The hydraulic signals provide a different forward generator from the training prior, while using the same known network. This is a transfer check within the tutorial's controlled setting.

Changing sensors, their order, the physical graph or the source domain requires consistent data and model preparation. Changing source counts or the split seed also requires verifying or regenerating the hydraulic test set so that it remains held out.

## Interpreting the two metrics

**Pipe accuracy** is the fraction of evaluated events assigned to the correct original pipe.

**Mean network-distance error** is the average shortest physical distance between the true and predicted continuous points. The calculation includes travel from each point to its original pipe endpoints and along the physical network; for two points on the same pipe, the direct separation is also considered.

Every evaluated prediction contributes to distance error, including wrong-pipe predictions. A neighbouring pipe near a junction may produce a small distance error, while a correct pipe with the wrong fraction may produce a large one. Report the event count and any unavailable observations so that these quantities remain interpretable.

## Observability and scope

If every sensor can be reached from a source pipe through the same endpoint, moving the source along that pipe may add the same delay to every sensor. Relative timing removes that common delay, leaving an unchanged signature. The within-pipe position is then unidentifiable from these observations. The sensor explorer makes this limitation visible.

Training with uncertain examples teaches a response to the selected error distribution. It does not remove an exact ambiguity, provide observations at uninstrumented locations, or establish transfer to a new topology. The tutorial concerns one known network with a specified sensor layout. Larger hydraulic test sets, different operating conditions and field observations are further experiments.
