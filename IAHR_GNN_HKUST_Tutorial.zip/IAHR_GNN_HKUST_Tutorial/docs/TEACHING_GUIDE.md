# Teaching guide: one signal, one question

**Question to carry through the hour:** We recorded a pressure disturbance. Where did it come from?

The case throughout is the retained HKUST primary network, with 31 nodes and 33 pipes. Its 21 pipes of at least 100 m define the default source domain; the short pipes remain in the graph.

By the end, participants should be able to describe a pipe network as a graph, distinguish observations from learned embeddings, explain one message-passing update, and follow the construction of a model that predicts a pipe and a position within it.

## Before the lecture

- Complete the setup in `SETUP.md`, select the tutorial kernel and run the notebook once.
- Use the supplied model and cached signals for the main walkthrough. Prepare optional training or new hydraulic runs before presenting.
- Keep prepared event 01 hidden at the start, and retain that event when introducing graph predictions. Its source was selected before model evaluation. Use the sensor control to inspect the same event from another junction.
- Leave the diagnostic output available. It makes the active kernel, library versions and CPU/GPU choice visible if anything needs checking.
- Use the notebook's static figures if the presentation environment cannot display live widgets. Interactive controls require a running notebook kernel.
- Use a browser zoom that leaves both the network and signal panel readable. Hide the file browser when projecting.

## Suggested sequence

| Minutes | Teaching action | Interpretation prompt |
|---|---|---|
| 0–6 | Show the network, the sensor locations and a recorded transient. Hide the source. | Which parts of this picture are measured, known or unknown? |
| 6–8 | Explain passive monitoring and briefly introduce the application and graph-learning references. | Does passive monitoring mean the hydraulic event has no cause? |
| 8–16 | Define nodes, edges, paths, degree and weights. Link a network neighbourhood to its adjacency matrix. | If I move a node on the drawing, does its connectivity change? |
| 16–24 | Assign travel-time costs and predict first arrivals from an interior source. Overlay predictions and signal picks. | Why does the first-arrival model not predict the later reflections? |
| 24–31 | Add background pressure noise and rerun the picker. Introduce optional additional timing uncertainty. | What changed: the physical propagation, the recorded pressure, or our estimate of arrival time? |
| 31–36 | Inspect input features and the initial embedding. | Which numbers did we supply, and which were learned? |
| 36–44 | Step through neighbour aggregation, updates and the two output heads. | What can a node learn from one update? What information was already supplied to every node? |
| 44–50 | Generate labelled timing examples with the graph prior. Explain splits, noisy training and validation. | Why must different noisy observations of the same source stay in one source split? |
| 50–56 | Return to hydraulic signals, predict the source and reveal the truth. Inspect the two metrics and individual failures. | Can a wrong pipe still be geographically close to the source? |
| 56–60 | Explore sensor placement, discuss ambiguity and set a short follow-up exercise. | Could more training recover a position that produces exactly the same relative arrival pattern? |

The timings are a suggested route through the prepared content. Detailed equations, assumptions and optional simulations remain available for follow-up use.

## Language that keeps the story clear

### The opening

A burst changes the local hydraulic condition and launches a disturbance. Sensors record the disturbance at different times. We want to use those observations to estimate its location. Monitoring is passive because we do not impose a diagnostic excitation on the operating system. In the tutorial, we deliberately simulate the event so that its true location is known for teaching and checking predictions.

Explain that T1 is a 40 m fixed-head supply in this controlled case, with initially zero demands and elevations. These declared simulation conditions let us study the transient without claiming to reproduce the current campus operating state.

Show the raw pressure-head record before introducing the processed burst response. Explain that the latter uses a no-burst reference to remove numerical initialisation drift in this controlled simulation.

### The graph

A graph records connections. Original names such as J10, T1 and P110_2 are identifiers, not distances or ranks. J84 provides a useful small neighbourhood for linking the map to the adjacency matrix. A hop is one connection, irrespective of its physical length. A path with fewer hops need not have the shortest travel time.

Keep three distinct objects visible:

- **Binary adjacency:** which nodes are connected.
- **Physical travel-time costs:** how long a wave takes to traverse a pipe in the prior.
- **Normalised adjacency for learning:** how neighbouring embeddings are combined.

Pipe wave speeds depend on diameter through the specified ductile-iron wall model. Ask why two pipes of the same length can therefore have different travel-time costs.

The same network supports these different mathematical objects. A message-passing layer does not perform a hydraulic simulation.

### The arrival overlay

Reveal the source for this explanatory stage. The known simulated onset and source let us draw a predicted absolute arrival line on a pressure record. The independent signal picker supplies another line. Their difference is informative and should remain visible.

During localisation, the model does not receive the true onset or source. Relative arrival features remove the unknown common onset. Describe the graph calculation as an approximation to earliest propagation, with differences caused by discretisation, boundaries, waveform development and the picker.

### The noisy record

Change one control at a time. First add pressure noise, keeping additional timing jitter at zero. Watch the picker respond. Then hold that waveform fixed and add extra timestamp uncertainty.

The noise standard deviation on a pressure plot is in metres of head. Timing jitter is in seconds or milliseconds. They are different quantities. At 100 Hz, one sample is 10 ms. An undetected arrival is an observation failure, not a zero-second arrival.

### The learned representation

Start with one node. The feature table combines its known relationship to sensors, the observed timing pattern and simple structural attributes. The learned encoder converts those supplied quantities into an embedding vector.

Then show the heatmap for all nodes and change the message-passing layer. Avoid assigning a hydraulic meaning to a hidden channel simply because it has a large value. The two-dimensional scatter is a projection of embeddings for inspection; its axes are not map coordinates.

### The two outputs

The model considers eligible original pipes. The pipe head produces scores and probabilities. Each pipe also has a position prediction measured from that pipe's original start node.

During training, the position term uses the true pipe's output. During inference, use the fraction associated with the selected pipe. A high softmax probability is not, by itself, a calibrated statement of physical certainty.

### How learning handles uncertain observations

A clean source signature generates many perturbed timing observations during training. The labels stay fixed while the observations change. This teaches the model to produce useful outputs across the chosen distribution of timing errors.

Training with noise does not give the model information that the sensors never measured. It also does not ensure that an unfamiliar noise distribution or a changed hydraulic state will be handled well. Treat the uncertainty controls as experiments that reveal behaviour.

## Useful student exercises

1. **Connections and delays.** Select a node, count its neighbours and identify a route with few hops. Check whether a longer route in hops can have a smaller total propagation cost.
2. **Unknown onset.** Add the same constant to every arrival time. Verify that the relative timing vector and prediction remain unchanged.
3. **Along-pipe motion.** Move a source between two interior positions. Explain which sensor arrivals change and whether subtracting the common reference removes that change.
4. **Two kinds of uncertainty.** Keep the event fixed. Record the result with clean signals, noisy signals, and noisy signals plus additional timestamp jitter. Explain each change without altering the source.
5. **Embeddings.** Select one node and one layer. Identify the input vector, the aggregated neighbour vector and the updated representation.
6. **A new sensor layout.** Inspect alternative junctions in the sensor explorer. Retrain before asking the model to predict from a changed sensor set or order.
7. **A new burst.** Run the optional simulator after the lecture. Change the opening duration and explain how the leading edge and pick change.

A short submission can contain the selected settings, two figures and a paragraph explaining what the participant learned. The emphasis is on interpreting the computation.

## Common misconceptions to address

| Statement | Clarification |
|---|---|
| A node without a sensor has no useful features. | Known graph attributes and travel-time landmarks are still available. In this design, the measured sensor vector is also supplied to every node. |
| Two GNN layers carry every local reading across the entire network. | They perform two neighbourhood updates. The global sensor vector is explicitly supplied as part of the feature design. |
| Adding pressure noise is the same as adding 10 ms to a timestamp. | Pressure noise changes what the picker sees; a timestamp perturbation directly changes the extracted arrival. |
| A shortest path describes the whole transient. | It approximates first-arrival timing. The full signal contains additional dynamics. |
| The source must be a graph node. | The output is an original pipe and a continuous fraction within it. |
| The best training epoch is always the last epoch. | Validation selects the saved model. Early stopping limits further fitting when validation no longer improves. |
| A correct pipe means zero location error. | The fraction within that pipe may still be wrong. |
| More epochs remove geometric ambiguity. | Identical observable signatures cannot distinguish their sources from these inputs alone. |

See `SCIENTIFIC_NOTES.md` for equations, data separation and numerical details, and `../REFERENCES.md` for sources.
