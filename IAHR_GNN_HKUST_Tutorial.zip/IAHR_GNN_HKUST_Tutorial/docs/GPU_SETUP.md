# GPU and CPU selection

The notebook selects a working NVIDIA CUDA device when available and otherwise uses CPU. GPU acceleration affects neural-network training and inference. TSNet's hydraulic simulations still run on CPU.

## Which package is installed?

This tutorial pins **PyTorch 2.7.1**, with a matching official CPU or CUDA wheel. Its Python 3.12 wheels are available for Windows and Linux x86-64. The installer uses the NVIDIA driver information and GPU compute capability, then verifies the result by performing an actual tensor calculation. A GPU name alone does not establish that CUDA works.

The **RTX 3070** has compute capability **8.6** and the **RTX 4060** has **8.9**. Both are compatible with the selected CUDA 11.8 / 12.6 paths when the installed driver meets the policy below. Modern NVIDIA drivers can run applications built with older supported CUDA runtimes.

| Build | Windows driver used by this setup | Linux driver used by this setup | Automatic use |
|---|---:|---:|---|
| `cu126` | 561.17 or newer | 560.35.05 or newer | Preferred for the RTX 3070 / 4060 and other verified pre-Blackwell cards |
| `cu118` | 522.06 or newer | 520.61.05 or newer | Compatible older-driver path for these cards |
| `cu128` | 572.61 or newer | 570.124.06 or newer | Newer supported architectures requiring CUDA 12.8 |
| `cpu` | No NVIDIA driver needed | No NVIDIA driver needed | No suitable NVIDIA device/driver, an unknown architecture, or explicit `--cpu` |

These are deliberately conservative toolkit driver thresholds, including CUDA 12.6 Update 3 / 12.8 Update 1. NVIDIA's minor-version compatibility rules sometimes allow lower drivers, but this automatic setup does not rely on those exceptions. Unknown future hardware is not assumed compatible with these pinned wheels.

The `CUDA Version` displayed by `nvidia-smi` describes driver capability. It is not the installed PyTorch build and does not need to equal `torch.version.cuda`. The pip wheels supply their runtime dependencies. You do not need to install the CUDA Toolkit or `nvcc` to use this notebook.

## Inspect your setup

In the activated tutorial environment:

```text
nvidia-smi
python scripts/install_torch.py --dry-run
python scripts/check_environment.py
```

Inside the notebook:

```python
import sys, torch
print("Python:", sys.executable)
print("PyTorch:", torch.__version__)
print("CUDA build:", torch.version.cuda)
print("CUDA available:", torch.cuda.is_available())
```

`2.7.1+cpu` is the CPU build. A suffix such as `+cu126` identifies a CUDA build, but the real execution check must also succeed. `scripts/check_environment.py --require-cuda` exits with an error if that tensor calculation fails.

## Change machines or repair a CPU-only install

Create the same new environment on the other computer using the supplied setup script. It selects its package for that machine. Do not copy an installed Conda environment directory between computers.

If you installed the CPU build before enabling your NVIDIA driver:

```text
conda activate iahr-gnn-hkust-tutorial
python scripts/install_torch.py
python scripts/check_environment.py
```

Restart Jupyter's kernel afterwards. To explicitly install the CPU build:

```text
python scripts/install_torch.py --cpu
```

Advanced users can request `--cuda cu126`, `--cuda cu118` or `--cuda cu128`. The installer still checks the driver and architecture. If the request is unsuitable, it selects CPU and explains why. It never updates a graphics driver automatically.

If a CUDA wheel installs but its GPU calculation fails while CPU calculation succeeds, the notebook can use that package on CPU. If installing/importing the CUDA package fails, setup tries the CPU wheel once. It does not cycle through several large GPU downloads.

## Sources and verification scope

- [Official PyTorch previous-version installation commands](https://pytorch.org/get-started/previous-versions/), section 2.7.1. The package is pinned for this teaching environment, rather than tracking the newest release automatically.
- [Official PyTorch CUDA 12.6 wheel index](https://download.pytorch.org/whl/cu126/torch/), including Python 3.12 Windows and Linux wheels.
- [NVIDIA CUDA GPU compute capabilities](https://developer.nvidia.com/cuda/gpus), including RTX 3070 and RTX 4060.
- [NVIDIA CUDA Toolkit release notes](https://docs.nvidia.com/cuda/cuda-toolkit-release-notes/), corresponding driver versions for CUDA 12.6 / 12.8.
- [NVIDIA CUDA 11.8 release notes](https://docs.nvidia.com/cuda/archive/11.8.0/cuda-toolkit-release-notes/index.html), Table 3.
- [NVIDIA architecture and toolkit compatibility matrix](https://docs.nvidia.com/datacenter/tesla/drivers/cuda-toolkit-driver-and-architecture-matrix.html).

Installer selection is unit-tested with representative Windows/Linux driver and GPU records, including RTX 3070/4060, missing drivers and newer architectures. Local execution checks are CPU checks; native Windows and physical NVIDIA GPU execution are not claimed unless explicitly recorded in the project's verification report. The GitHub workflow runs fresh Windows and Linux CPU checks after you upload the project and enable Actions.
