# Start the tutorial in a new Conda environment

The project uses the separate environment **`iahr-gnn-hkust-tutorial`** and Jupyter kernel **Python (IAHR GNN HKUST Tutorial)**. Keep the complete extracted folder together. Its notebook imports the adjacent Python modules and reads the included network, model and signals.

## If the previous tutorial already runs

The HKUST edition uses the same dependencies. You can open its notebook with your existing working **Python (IAHR GNN Tutorial)** kernel; no package reinstall is needed. Enter the extracted HKUST project folder before starting Jupyter. The setup steps below create a separate environment when you want an isolated installation or are setting up another computer.

## Windows: Anaconda Prompt

1. Download and extract the ZIP. Open the extracted folder that actually contains `setup_windows.bat`, `environment.yml` and `IAHR_GNN_HKUST_Tutorial.ipynb`.
2. In File Explorer, click the address bar and copy that folder's full path.
3. Open **Anaconda Prompt**. Type `cd /d ` followed by the copied path in double quotes. For example, if you extracted it in Documents:

   ```bat
   cd /d "%USERPROFILE%\Documents\IAHR_GNN_HKUST_Tutorial"
   dir environment.yml
   setup_windows.bat
   ```

   If `dir environment.yml` says the file is missing, navigate into the inner project folder before running setup. Windows ZIP extraction sometimes adds an extra directory level.

4. After setup reports success:

   ```bat
   conda activate iahr-gnn-hkust-tutorial
   jupyter lab
   ```

5. Open `IAHR_GNN_HKUST_Tutorial.ipynb`. Select **Kernel > Change Kernel > Python (IAHR GNN HKUST Tutorial)**. Use **Kernel > Restart Kernel and Run All Cells** for the prepared walkthrough.

Setup creates the environment, installs the dependencies, chooses an appropriate PyTorch build, performs a real tensor calculation, and registers the kernel. It does not update another Conda environment or your graphics driver. Internet access is needed for this first installation. The included examples then run locally.

For a computer without an NVIDIA GPU, or to request CPU execution explicitly:

```bat
setup_windows.bat --cpu
```

The setup script can be rerun if a download is interrupted. It reuses the environment named above. Read the printed error if installation stops; repeated retries will not solve a blocked internet connection.

## Linux or macOS

Install Miniconda or Anaconda first, open a terminal with `conda` available, and enter the extracted project folder:

```bash
bash setup_unix.sh
conda activate iahr-gnn-hkust-tutorial
jupyter lab
```

Windows and Linux x86-64 are the supported setup targets. The script selects CPU execution on macOS and other platforms. The TSNet/WNTR binary dependency stack may require additional platform-specific support there. No Apple GPU or AMD GPU path is enabled by this tutorial.

## Equivalent commands, one step at a time

Run these from the project folder if you prefer to see each step:

```text
conda env create -f environment.yml
conda activate iahr-gnn-hkust-tutorial
python -m pip install -r requirements.txt
python scripts/install_torch.py
python -m ipykernel install --user --name iahr-gnn-hkust-tutorial --display-name "Python (IAHR GNN HKUST Tutorial)"
python scripts/check_environment.py
jupyter lab
```

PyTorch is installed separately from `requirements.txt` so a CPU package does not overwrite a working GPU package. No PyTorch Geometric installation is required.

## Working in Jupyter

- **Shift + Enter:** run the current cell, then move to the next cell.
- **Run All Cells:** run from top to bottom. The kernel shows **Busy** while working and **Idle** when finished.
- **Kernel > Interrupt Kernel:** stop an optional training run. The next completed-epoch checkpoint is the safe point for resumption; see the notebook's training controls.
- **Kernel > Restart Kernel and Run All Cells:** clear previous variables and repeat the prepared walkthrough.
- Widgets respond after their cells have run in the live kernel. Saved PNG figures remain visible without an active kernel.
- After editing a `.py` module, restart the kernel so Python imports that new code.

For another session, open Anaconda Prompt, enter the same project folder, activate `iahr-gnn-hkust-tutorial`, and run `jupyter lab`. There is no need to reinstall.

## If something looks wrong

| Symptom | What to check |
|---|---|
| `requirements.txt` cannot be found | Use the directory containing that actual file. Do not run from the ZIP viewer. |
| A module is missing despite installation | Check the Jupyter kernel and the printed `sys.executable`; the environment and kernel must both be `iahr-gnn-hkust-tutorial`. |
| `conda` is not recognised | Use Anaconda Prompt / Miniconda Prompt, or initialise Conda for your shell. |
| `CUDA available: False` | The tutorial continues on CPU. Run `python scripts/check_environment.py` and read [GPU_SETUP.md](GPU_SETUP.md). |
| GPU memory runs out during training | Restart the kernel, close other GPU tasks and reduce the training batch size. Keep the prepared walkthrough on CPU if needed. |
| Widgets show only text | Confirm `ipywidgets` is installed in the selected kernel, restart JupyterLab and rerun the widget cells. |
| A new sensor layout rejects the saved model | This is intentional. Restore the default sensors or follow the notebook's fresh-training workflow. |

The scripts write hardware and import diagnostics to `outputs/setup_report.json` and `outputs/environment_report.json` for your own troubleshooting. These machine-specific files are excluded from Git.
