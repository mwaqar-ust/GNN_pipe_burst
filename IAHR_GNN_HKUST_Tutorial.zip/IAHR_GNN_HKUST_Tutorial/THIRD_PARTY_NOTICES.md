# Sources and notices

The retained HKUST network geometry in `networks/hkust_primary_network.csv` and the controlled hydraulic input `networks/HKUST.inp` come from the author-supplied HKUST/ICHD materials. Their hashes and physical assumptions are recorded in `networks/provenance.json`. The supplied source notice is retained in `networks/SOURCE_LICENSE.md`.

TSNet, WNTR, PyTorch, NumPy, SciPy, pandas, Matplotlib, NetworkX and Jupyter are installed as dependencies. Their source code and licenses remain with their respective projects.

The hydraulic arrays and compact GNN weights were generated afresh for this tutorial on the supplied network. Source selection and simulation settings are recorded in `data/tsnet_manifest.json` and the metadata within `data/tsnet_test.npz`. Training configuration and verification are recorded in `data/`.

Citation information describes authorship and scholarly context. It does not replace a software or data license. No new project-wide reuse license is assigned on the authors' behalf by this package.
