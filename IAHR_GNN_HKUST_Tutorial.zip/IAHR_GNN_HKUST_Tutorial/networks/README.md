# HKUST case network

The supplied CSV preserves the retained HKUST primary-network pipe IDs, endpoint IDs, geographic coordinates, measured pipe lengths, diameters and source roughness field. `HKUST.inp` preserves that topology and the stored direction of every pipe. The learning target fraction is measured from its original start node.

The INP is a controlled transient teaching setup: T1 is a 40 m fixed-head reservoir, all junction elevations and initial demands are zero, and the transient calculation uses Darcy friction factor 0.02. The CSV roughness column (130) is not substituted for this Darcy factor. Longitude/latitude coordinates are projected into local metres for plots and coordinate features; physical travel times and localisation errors use the supplied pipe lengths.

The source model contains 31 nodes and 33 pipes. The tutorial's 100 m source threshold retains 21 candidate burst pipes; all 33 pipes still belong to the graph and hydraulic model. Diameter-dependent wave speeds are specified in `network_config.py`. Source-independent numerical discretisation produces the effective speeds used by the travel-time prior.

`provenance.json` records the input hashes and assumptions. `SOURCE_LICENSE.md` retains the supplied source notice. These data do not establish a calibrated model of current campus operations.
